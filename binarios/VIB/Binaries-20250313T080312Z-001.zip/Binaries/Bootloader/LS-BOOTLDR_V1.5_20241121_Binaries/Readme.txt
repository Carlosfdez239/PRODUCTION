
Below is the start address of each binary to flash in the controller
boardstr.bin       - Start Address: 0xc019fd0
sbsfu_boot.bin     - Start Address: 0xc004000
loader.bin         - Start Address: 0xc3d2000
s_app_enc_sign.bin - Start Address: 0xc17e000

