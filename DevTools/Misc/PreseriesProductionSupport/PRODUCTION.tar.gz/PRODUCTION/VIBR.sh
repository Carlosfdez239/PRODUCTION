#!/bin/bash

make VIB
